HYPERCREATIVE LOGO PACK

Files in this pack:
  hypercreative-wordmark-light.svg / .png  Wordmark for light backgrounds (dark word, red dot).
  hypercreative-wordmark-dark.svg  / .png  Wordmark for dark backgrounds (light word, red dot).
  hypercreative-symbol.svg                 The symbol on its own (the red ignition dot).
  hypercreative-favicon.svg                Favicon.
  hypercreative-brand-prompt.txt           A prompt you can paste into any AI to use the logo correctly.

Quick rules:
  Use these files unchanged. Never re-type, recolour, stretch or rotate the logo. Keep the red dot.
  Light background uses the light-background version; dark background uses the dark version.

Full manual: https://hypercreativemethod.com/assets/press/Hypercreative-Brand-Manual.pdf
Everything, and the ready-to-copy prompt: https://hypercreativemethod.com/press/
Hypercreative is a trademark.
